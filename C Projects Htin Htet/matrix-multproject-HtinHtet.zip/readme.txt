To run matrix-mult:

./matrix-mult data1.txt
./matrix-mult data2.txt