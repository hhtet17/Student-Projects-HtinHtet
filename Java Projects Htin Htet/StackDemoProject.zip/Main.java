/*
 * Htin L Htet
 * Eric Gonzales
 * ACO 201
 * Project 1
 */
public class Main {
	
	public static String[] reverseWords(String[] wordlist)
	{
		
		Stack<String> reverse = new Stack<String>();
		String reverseList[] = {" "," "," "," " };
		
		for(int i = 0; i < wordlist.length; i++) //pushes all Strings in original wordlist into a Stack<String>
		{
			reverse.push(wordlist[i]);
			
		}
		
		for(int j = 0; j <wordlist.length; j++) //pops back Strings into wordlist last-in first-out style
		{
			wordlist[j] = reverse.pop();
		}
		return wordlist;
	}
	
	public static boolean expressionDelimiterMatch(String expression)
	{
		Stack<Character> input = new Stack<Character>();
		int length = expression.length();
		for(int i = 0; i < length;i++) //traverses through expression
		{
			char index = expression.charAt(i);
			char index2;
			if(index == '{'|| index == '('|| index == '[') // receives opening bracket and pushes it into the Stack Array
			{
				input.push(index);
			}
			
			if(input.isEmpty()) // if input contains empty or non-bracket characters, it will not make a valid Stack Array
			{
				System.out.println(" List invalid or empty");
				return false;
			}
			
			switch(index) { //when index of expression is now closing brackets, it will match it with its opening bracket and push the opening brackets
							// when it does not match, it returns false statement
			case '}':
				index2 = input.pop();
				if(index2 == '[')
					return false;
					
					
				if(index2 == '(')	
					return false;
				
					break;
					
				
			case ')':
				index2 = input.pop();
				if(index2 == '{')
					return false;
					
					
				if(index2 == '[')	
					return false;
				
					break;
				
			case ']':
				index2 = input.pop();
				if(index2 == '(')
					return false;
					
					
				if(index2 == '{')	
					return false;
				
					break;
					
			}
			
		
		}
		 if(input.isEmpty()) //if all correlating opening brackets are pop(), they stack array will be 
			 				 // empty and return true. this means that all matching closing bracket took out each opening bracket last-in first-out
		 {
			 return true;
		 }
		 else
		 {
			 return false;
		 }
		
		
	}
	public static void main(String[] args) {
		
		System.out.println("\n ACO 201: Project1, Htin Htet, Eric Gonzales \n");
		System.out.println("\n This project implements and demonstrates Stack ADT. \n The following code takes a string of brackets/parenthesis to find corresponding opening/closing pair and returns a boolean.\n This code also contains a method that reverses a String list. \n");		
			
		String expression = "()(()){{}}{[()]}";
		String expression2 = "[(]";
		String expression3 = "(){}[]([])((({{()}})))";
		System.out.println("Expression1: "+ expression + ": " + expressionDelimiterMatch(expression));
		System.out.println("Expression2: "+ expression2 + ": " + expressionDelimiterMatch(expression2));
		System.out.println("Expression3: "+ expression3 + ": " + expressionDelimiterMatch(expression3));
		String wordList[] = {"Bird","Cat","Dog","Elephant"};
		reverseWords(wordList);
		
		for(int i = 0; i < wordList.length; i++)
		{
			System.out.print(wordList[i] + " ");
		}
		
	}

}
