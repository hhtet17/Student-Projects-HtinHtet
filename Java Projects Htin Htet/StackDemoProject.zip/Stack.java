/*
 * Htin L Htet
 * Eric Gonzales
 * ACO 201
 * Project 1
 */
import java.util.*;
public class Stack<E> {
	
	int size;
	
	ArrayStack<E> top;
	
	public Stack() //simple Stack Instructor
	{
		size = 0;
		top = null;
	}
	public void push(E newValue) //adds element to stack
	{
		ArrayStack<E> newElement = new ArrayStack<E>(newValue,top);
		top = newElement;
		size++;
	}
	public E pop() //deletes and returns element
	{
		ArrayStack<E> oldTop = top;
		if(oldTop == null)
		{
			return null;
		}
		top = top.getNext(); 
		size--;
		return oldTop.getValue(); 
	}
	
	public Boolean isEmpty()
	{
		if(size == 0)
		{
			return true;
		}
		if(top == null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
	
}
