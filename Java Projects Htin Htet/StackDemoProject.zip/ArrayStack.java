/*
 * Htin L Htet
 * Eric Gonzales
 * ACO 201
 * Project 1
 */
public class ArrayStack<E>{
	
	E value;
	ArrayStack<E> next;
	
	public ArrayStack(E value, ArrayStack<E> next) //ArrayStack Constructor
	{
		this.value = value;
		this.next = next;
	}
	
	public ArrayStack<E> getNext()
	{
		return next;
	}
	
	public E getValue()
	{
		return value;
	}


}
